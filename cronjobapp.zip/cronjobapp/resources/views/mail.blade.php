<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
</head>
<body>
	Hi, <h5>{{ $name }}</h5>
	<p>{{ $body }}</p>
</body>
</html>