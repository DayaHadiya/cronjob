<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Models\User;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::create([
            'name' => 'smith',
            'email' => 'smith@gmail.com',
            'password' => bcrypt('123')
        ]);

        User::create([
            'name' => 'john',
            'email' => 'john@gmail.com',
            'password' => bcrypt('123')
        ]);
    }
}
