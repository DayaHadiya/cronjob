<!DOCTYPE html>
<html>
<head>
	<title>Welcome</title>
</head>
<body>
	Hi, <h5><?php echo e($name); ?></h5>
	<p><?php echo e($body); ?></p>
</body>
</html><?php /**PATH C:\xampp\cronjobapp\resources\views/mail.blade.php ENDPATH**/ ?>