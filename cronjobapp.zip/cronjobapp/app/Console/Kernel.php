<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Console\Commands\Sendmailtouser;

class Kernel extends ConsoleKernel
{
    protected $commands = [
        Sendmailtouser::class,
    ];
    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // $schedule->command('inspire')->hourly();
        //$schedule->command('sendmailtouser')->hourly();
        /*$schedule->call(function() {
          $cronitor->job('sendmailtouser', new DailyMetricsTask);
        })->hourly();*/
        $cronitor = new Cronitor\Client(config('services.cronitor.api_key'));
        $taskName = 'sendmailtouser';
        $monitor = $cronitor->monitor($taskName);
        $schedule->command($taskName)
          ->hourly()
          ->before(function() { $monitor->ping(['state' => 'run']); })
          ->onSuccess(function() { $monitor->ping(['state' => 'complete']); })
          ->onFailure(function() { $monitor->ping(['state' => 'fail']); });
            }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
